# WSO2 Configurator

Configurator is a python module which provides features for configuring a server with set of name value pairs.
A template module needs to be created with a set of jinja template files and a configuration settings ini file for using
configurator for configuring a server.

## WSO2 Configurator Templates
```
https://github.com/wso2/product-private-paas/tree/master/cartridges/configurator-templates
```